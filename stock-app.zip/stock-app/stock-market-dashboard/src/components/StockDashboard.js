// import React, { Component } from 'react';
// import './StockDashboard.css'; // Import custom CSS
// import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap
// import io from 'socket.io-client';

// class StockDashboard extends Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//       stockSymbol: '',
//       stockPrice: null,
//     };
//     this.previousSearches = [];  // Uncontrolled component for storing previous searches
  

//   this.socket = io('http://localhost:5000');
//   };
//   componentDidMount() {
//     this.fetchStockData('AAPL');
//   }

//   componentDidUpdate(prevProps, prevState) {
//     if (prevState.stockSymbol !== this.state.stockSymbol) {
//       this.fetchStockData(this.state.stockSymbol);
//     }
//   }

//   fetchStockData(symbol) {
//     console.log(`Fetching data for: ${symbol}`);
//     setTimeout(() => {
//       this.setState({ stockPrice: (Math.random() * 1000).toFixed(2) });
//       this.previousSearches.push(symbol); // Store the previous search
//     }, 1000);
//   }

//   handleInputChange = (e) => {
//     this.setState({ stockSymbol: e.target.value });
//   };

//   render() {
//     const { stockSymbol, stockPrice } = this.state;

//     return (
//       <div className="container">
//         <div className="row">
//           <div className="col-12">
//             <h1 className="text-center mt-5">Stock Market Dashboard</h1>
//           </div>
//           <div className="col-12">
//             <div className="card">
//               <div className="card-header">
//                 Stock Price for: {stockSymbol || 'Enter a symbol'}
//               </div>
//               <div className="card-body">
//                 {stockPrice ? (
//                   <h2 className="text-center">${stockPrice}</h2>
//                 ) : (
//                   <h3 className="text-center">Loading...</h3>
//                 )}
//               </div>
//             </div>
//           </div>
//           <div className="col-12 mt-4">
//             <input
//               type="text"
//               className="form-control"
//               placeholder="Enter Stock Symbol"
//               value={stockSymbol}
//               onChange={this.handleInputChange}
//             />
//           </div>
//           <div className="col-12 mt-4">
//             <h4>Previous Searches:</h4>
//             <ul>
//               {this.previousSearches.map((search, index) => (
//                 <li key={index}>{search}</li>
//               ))}
//             </ul>
//           </div>
//         </div>
//       </div>
//     );
//   }
// }

// export default StockDashboard;



// -----------------------------------------



import React, { Component } from 'react';
import './StockDashboard.css'; // Import custom CSS
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap
import io from 'socket.io-client';

class StockDashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      stockSymbol: '',
      stockPrice: null,
      isDarkMode: false, // State to track the mode (light or dark)
    };
    this.previousSearches = [];  // Uncontrolled component for storing previous searches
  
    this.socket = io('http://localhost:5000');
  }

  componentDidMount() {
    this.fetchStockData('AAPL');
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.stockSymbol !== this.state.stockSymbol) {
      this.fetchStockData(this.state.stockSymbol);
    }
  }

  fetchStockData(symbol) {
    console.log(`Fetching data for: ${symbol}`);
    setTimeout(() => {
      this.setState({ stockPrice: (Math.random() * 1000).toFixed(2) });
      this.previousSearches.push(symbol); // Store the previous search
    }, 1000);
  }

  handleInputChange = (e) => {
    this.setState({ stockSymbol: e.target.value });
  };

  // Method to toggle between light and dark modes
  toggleTheme = () => {
    this.setState((prevState) => ({
      isDarkMode: !prevState.isDarkMode, // Toggle the theme
    }));
  };

  render() {
    const { stockSymbol, stockPrice, isDarkMode } = this.state;

    return (
      <div className={`container ${isDarkMode ? 'dark-mode' : 'light-mode'}`}>
        <div className="row">
          <div className="col-12">
            <h1 className="text-center mt-5">Stock Market Dashboard</h1>
          </div>
          <div className="col-12">
            <div className="card">
              <div className="card-header">
                Stock Price for: {stockSymbol || 'Enter a symbol'}
              </div>
              <div className="card-body">
                {stockPrice ? (
                  <h2 className="text-center">${stockPrice}</h2>
                ) : (
                  <h3 className="text-center">Loading...</h3>
                )}
              </div>
            </div>
          </div>
          <div className="col-12 mt-4">
            <input
              type="text"
              className="form-control"
              placeholder="Enter Stock Symbol"
              value={stockSymbol}
              onChange={this.handleInputChange}
            />
          </div>
          <div className="col-12 mt-4">
            <h4>Previous Searches:</h4>
            <ul>
              {this.previousSearches.map((search, index) => (
                <li key={index}>{search}</li>
              ))}
            </ul>
          </div>
        </div>
        {/* Button to toggle theme */}
        <div className="col-12 text-center mt-4">
          <button 
            className="btn btn-secondary"
            onClick={this.toggleTheme}
          >
            {isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          </button>
        </div>
      </div>
    );
  }
}

export default StockDashboard;
