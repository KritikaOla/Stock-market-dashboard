// const express = require('express');
// const http = require('http');
// const socketIo = require('socket.io');
// const axios = require('axios');

// // Set up Express app and HTTP server
// const app = express();
// const server = http.createServer(app);
// const io = socketIo(server);

// // A simple route for checking the server
// app.get('/', (req, res) => {
//   res.send('Stock Price Server is Running');
// });

// // Socket.io connection
// io.on('connection', (socket) => {
//   console.log('A user connected');
  
//   // Listen for a request to fetch stock data
//   socket.on('requestStockPrice', async (stockSymbol) => {
//     console.log(`Fetching stock data for ${stockSymbol}`);
    
//     try {
//       const stockData = await fetchStockData(stockSymbol);
//       socket.emit('stockPriceUpdate', stockData);
//     } catch (error) {
//       console.error('Error fetching stock data', error);
//       socket.emit('error', 'Error fetching stock data');
//     }
//   });

//   // Handle disconnection
//   socket.on('disconnect', () => {
//     console.log('User disconnected');
//   });
// });

// // Function to fetch stock data from an external API
// const fetchStockData = async (symbol) => {
//   const apiKey = '05OHRQXX3148M4AL'; // Replace with your API key (e.g., Alpha Vantage)
//   const url = `https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=${symbol}&interval=5min&apikey=${apiKey}`;

//   const response = await axios.get(url);
//   const timeSeries = response.data['Time Series (5min)'];
  
//   // Get the most recent stock data
//   const latestTime = Object.keys(timeSeries)[0];
//   const stockPrice = timeSeries[latestTime]['1. open'];

//   return {
//     symbol,
//     stockPrice,
//     time: latestTime,
//   };
// };

// // Start the server
// const port = process.env.PORT || 5000;
// server.listen(port, () => {
//   console.log(`Server is running on port ${port}`);
// });


const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const axios = require('axios');
const cors = require('cors');  // Allow CORS requests from frontend

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Enable CORS for the frontend
app.use(cors());

// Serve a simple route to check if the server is running
app.get('/', (req, res) => {
  res.send('Stock Price Server is Running');
});

// Socket.io connection event
io.on('connection', (socket) => {
  console.log('A user connected');

  // Listen for the 'requestStockPrice' event from the frontend
  socket.on('requestStockPrice', async (stockSymbol) => {
    console.log(`Received request for stock symbol: ${stockSymbol}`); // Debug log

    try {
      const stockData = await fetchStockData(stockSymbol);  // Fetch stock data from API
      if (stockData) {
        console.log('Fetched stock data:', stockData);  // Debug log
        socket.emit('stockPriceUpdate', stockData);  // Emit stock data back to frontend
      } else {
        socket.emit('error', 'Invalid Stock Symbol');  // Emit error if no data found
      }
    } catch (error) {
      console.error('Error fetching stock data:', error);
      socket.emit('error', 'Error fetching stock data');
    }
  });

  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

// Function to fetch stock data from Alpha Vantage or another API
const fetchStockData = async (symbol) => {
  const apiKey = '05OHRQXX3148M4AL';  // Replace with your Alpha Vantage API key
  const url = `https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=${symbol}&interval=5min&apikey=${apiKey}`;

  try {
    const response = await axios.get(url);
    const timeSeries = response.data['Time Series (5min)'];

    if (timeSeries) {
      const latestTime = Object.keys(timeSeries)[0]; // Get the most recent timestamp
      const stockPrice = timeSeries[latestTime]['1. open']; // Get the stock price for that timestamp

      return {
        symbol,
        stockPrice,
        time: latestTime,
      };
    } else {
      return null; // Return null if no stock data is found
    }
  } catch (error) {
    console.error('Error fetching stock data:', error);
    return null;
  }
};

// Start the server on port 5000
const port = process.env.PORT || 5000;
server.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
